import SwiftUI

@main
struct XPadelApp: App {
    @StateObject private var router = Router()

    init() {
        let tab = UITabBarAppearance()
        tab.configureWithOpaqueBackground()
        tab.backgroundColor = UIColor(Color.xBg)
        UITabBar.appearance().standardAppearance = tab
        UITabBar.appearance().scrollEdgeAppearance = tab
        let nav = UINavigationBarAppearance()
        nav.configureWithOpaqueBackground()
        nav.backgroundColor = UIColor(Color.xBg)
        nav.titleTextAttributes = [.foregroundColor: UIColor.white]
        nav.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        UINavigationBar.appearance().standardAppearance = nav
        UINavigationBar.appearance().scrollEdgeAppearance = nav
    }

    var body: some Scene {
        WindowGroup {
            RootTabs().environmentObject(router).preferredColorScheme(.dark).accentColor(.xAccent)
                .dynamicTypeSize(...DynamicTypeSize.xxxLarge)
        }
    }
}

final class Router: ObservableObject {
    @Published var tab = 0
}

struct RootTabs: View {
    @EnvironmentObject var router: Router
    var body: some View {
        TabView(selection: $router.tab) {
            HomeView().tabItem { Label("Главная", systemImage: "house.fill") }.tag(0)
            ServicesView().tabItem { Label("Услуги", systemImage: "list.bullet") }.tag(1)
            BookingView().tabItem { Label("Запись", systemImage: "calendar.badge.plus") }.tag(2)
            CoachesView().tabItem { Label("Тренеры", systemImage: "figure.tennis") }.tag(3)
            MoreView().tabItem { Label("Клуб", systemImage: "ellipsis.circle") }.tag(4)
        }
    }
}
