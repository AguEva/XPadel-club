# XPadel — клиентское приложение (iOS, SwiftUI)

Данные клуба — в `XPadel/Content.swift`, цвета — в `XPadel/Theme.swift`, экраны — в `XPadel/Screens.swift`.
Онлайн-запись открывает страницу YClients внутри приложения (`Club.bookingURL`).
