import Foundation

// Вся информация о клубе — в одном месте (взята с https://xpadel33.ru/).
enum Club {
    static let name = "XPadel"
    static let slogan = "Место, где спорт встречается со стилем"
    static let city = "Владимир"
    static let address = "г. Владимир, ул. Дворянская, д. 27Ак2, Бизнес-парк «Техника»"
    static let landmark = "Рядом с Золотыми Воротами"
    static let hours = "Ежедневно, с 08:00 до 22:00"
    static let courts = 4

    static let phoneDisplay = "+7 (920) 907 88-87"
    static let phoneURL = "tel:+79209078887"
    static let email = "XPadelclubb@gmail.com"

    static let site = "https://xpadel33.ru"
    static let bookingURL = "https://n1855686.yclients.ru"   // онлайн-запись YClients
    static let heroImage = "https://static.tildacdn.com/tild6433-3663-4632-b365-373934333532/Frame_16_2.jpg"
    static let banner = "https://static.tildacdn.com/tild6635-3039-4336-b134-323339646330/Frame_16_1.jpg"

    static let about = "XPadel — первый падел-клуб в центре Владимира. Место силы, общения и развития: индивидуальные и групповые тренировки, собственная команда тренеров и продуманная инфраструктура — от ресепшена до лаундж-зоны. Сюда приходят играть, отдыхать и становиться частью падел-сообщества."

    static let legal = "ИП Метлинова Мария Алексеевна\nИНН 332903809347\nОГРНИП 325330000069631"

    struct Feature: Identifiable { let id = UUID(); let icon: String; let title: String; let text: String }
    static let features: [Feature] = [
        Feature(icon: "square.grid.2x2", title: "\(courts) корта", text: "Современные падел-корты"),
        Feature(icon: "figure.tennis", title: "Тренеры", text: "Профессиональная команда"),
        Feature(icon: "shower", title: "Раздевалки и душ", text: "Премиальные раздевалки"),
        Feature(icon: "cup.and.saucer", title: "Лаундж-зона", text: "Отдых до и после игры"),
        Feature(icon: "tennis.racket", title: "Инвентарь", text: "Аренда ракеток на время игры"),
        Feature(icon: "calendar", title: "Онлайн-запись", text: "Быстро, удобно, без звонков"),
    ]

    struct Social: Identifiable { let id = UUID(); let icon: String; let title: String; let url: String }
    static let socials: [Social] = [
        Social(icon: "message.fill", title: "WhatsApp", url: "https://wa.me/79209078887"),
        Social(icon: "paperplane.fill", title: "Telegram", url: "https://t.me/xpadel_vladimir"),
        Social(icon: "person.2.fill", title: "VK", url: "https://vk.com/xpadel"),
        Social(icon: "camera.fill", title: "Instagram", url: "https://instagram.com/xpadel_vladimir"),
        Social(icon: "bubble.left.fill", title: "MAX", url: "https://max.ru/u/f9LHodD0cOL6hyX8JNstlEJjNTDa4n0-fG-9pegaM48tasnQD6cWXuGWkIk"),
    ]

    struct Doc: Identifiable { let id = UUID(); let title: String; let path: String }
    static let docs: [Doc] = [
        Doc(title: "Публичная оферта", path: "/oferta"),
        Doc(title: "Пользовательское соглашение", path: "/soglashenie"),
        Doc(title: "Политика обработки персональных данных", path: "/policy"),
    ]
}

// MARK: - Услуги и цены (за 1 час)
struct Service: Identifiable {
    let id: String
    let title: String
    let who: String
    let icon: String
    let dayPrice: Int?; let dayCourt: Int?       // ПН–ПТ до 15:00
    let price: Int; let court: Int?              // основной тариф
}

enum Prices {
    static let services: [Service] = [
        Service(id: "group", title: "Групповая тренировка", who: "4 человека", icon: "person.3.fill",
                dayPrice: 5100, dayCourt: 2850, price: 7000, court: 4000),
        Service(id: "trio", title: "Тренировка на троих", who: "3 человека", icon: "person.3",
                dayPrice: 4600, dayCourt: 2600, price: 6000, court: 3500),
        Service(id: "pair", title: "Парная тренировка", who: "2 человека", icon: "person.2.fill",
                dayPrice: 4100, dayCourt: 2350, price: 5500, court: 3250),
        Service(id: "solo", title: "Индивидуальная тренировка", who: "1 человек", icon: "person.fill",
                dayPrice: 3600, dayCourt: 2100, price: 5000, court: 3000),
        Service(id: "rent", title: "Аренда корта", who: "до 4 человек, без тренера", icon: "square.grid.2x2.fill",
                dayPrice: 2200, dayCourt: nil, price: 3000, court: nil),
    ]
    static let racket = "Аренда ракетки на время пребывания в клубе — 200–300 ₽"
    static let balls = "Корзина мячей входит в тренировки"
    static let note = "Цены указаны за 1 час. Актуальные цены и свободное время смотрите в онлайн-записи."
}

func rub(_ v: Int) -> String {
    let s = String(v)
    var out = ""
    for (i, ch) in s.reversed().enumerated() {
        if i > 0 && i % 3 == 0 { out.append(" ") }
        out.append(ch)
    }
    return String(out.reversed()) + " ₽"
}

// MARK: - Тренеры
struct Coach: Identifiable {
    let id: String
    let name: String
    let role: String
    let bio: String
    let facts: [String]
    let photo: String?
    let page: String
}

enum Coaches {
    static let all: [Coach] = [
        Coach(id: "coach1", name: "Даниил Геннадьевич", role: "Амбассадор клуба",
              bio: "Действующий игрок и тренер. Проводит индивидуальные и групповые занятия, обучает с нуля, работает над техникой и тактикой игры.",
              facts: ["Кандидат в мастера спорта", "Многократный победитель и призёр всероссийских турниров", "Тренер месяца", "Тренерский стаж — 5 лет"],
              photo: "https://static.tildacdn.com/tild6536-3961-4634-a132-626663373166/IMG_0002_resized.jpg",
              page: "/coach1"),
        Coach(id: "coach2", name: "Константин Юрьевич", role: "Тренер XPadel",
              bio: "Тренер команды XPadel. Подробнее — на странице тренера на сайте клуба.",
              facts: [], photo: nil, page: "/coach2"),
        Coach(id: "coach3", name: "Александр Андреевич", role: "Тренер XPadel",
              bio: "Тренер команды XPadel. Подробнее — на странице тренера на сайте клуба.",
              facts: [], photo: nil, page: "/coach3"),
    ]
}
