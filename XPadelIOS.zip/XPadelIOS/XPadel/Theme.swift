import SwiftUI
import WebKit

// MARK: - Цвета (подобраны по чёрно-белым логотипам сайта; акцент — цвет падел-мяча).
// Если у клуба есть фирменные цвета, поменяйте значения здесь — они применятся во всём приложении.
extension Color {
    static let xBg = Color(red: 0.043, green: 0.043, blue: 0.047)       // #0B0B0C
    static let xCard = Color(red: 0.086, green: 0.086, blue: 0.094)     // #161618
    static let xLine = Color(red: 0.16, green: 0.16, blue: 0.17)
    static let xText = Color.white
    static let xMuted = Color(red: 0.60, green: 0.60, blue: 0.63)
    static let xAccent = Color(red: 0.776, green: 0.957, blue: 0.196)   // #C6F432
}

struct Card: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(16).background(Color.xCard).cornerRadius(18)
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.xLine, lineWidth: 1))
    }
}
extension View { func card() -> some View { modifier(Card()) } }

struct AccentButton: View {
    let title: String
    var icon: String? = nil
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if let icon { Image(systemName: icon) }
                Text(title.uppercased()).font(.system(size: 15, weight: .heavy)).tracking(0.6)
            }
            .foregroundColor(.black).frame(maxWidth: .infinity, minHeight: 54)
            .background(Color.xAccent).cornerRadius(27)
        }
    }
}

struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text.uppercased()).font(.system(size: 13, weight: .heavy)).tracking(1.6).foregroundColor(.xAccent)
    }
}

struct Wordmark: View {
    var size: CGFloat = 22
    var body: some View {
        HStack(spacing: 0) {
            Text("X").foregroundColor(.xAccent)
            Text("PADEL").foregroundColor(.white)
        }.font(.system(size: size, weight: .black)).tracking(2)
    }
}

// MARK: - Web
struct WebView: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        let w = WKWebView(frame: .zero, configuration: cfg)
        w.isOpaque = false
        w.backgroundColor = UIColor(Color.xBg)
        w.scrollView.backgroundColor = UIColor(Color.xBg)
        w.allowsBackForwardNavigationGestures = true
        w.load(URLRequest(url: url))
        return w
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct WebScreen: View {
    let title: String
    let url: String
    var body: some View {
        Group {
            if let u = URL(string: url) { WebView(url: u).ignoresSafeArea(edges: .bottom) }
            else { Text("Не удалось открыть страницу").foregroundColor(.xMuted) }
        }
        .background(Color.xBg.ignoresSafeArea())
        .navigationTitle(title).navigationBarTitleDisplayMode(.inline)
    }
}

struct RemoteImage: View {
    let url: String?
    var body: some View {
        if let url, let u = URL(string: url) {
            AsyncImage(url: u) { phase in
                switch phase {
                case .success(let img): img.resizable().scaledToFill()
                default: Color.xCard
                }
            }
        } else { Color.xCard }
    }
}

func openURL(_ s: String) {
    if let u = URL(string: s) { UIApplication.shared.open(u) }
}

// MARK: - Размеры экрана (приложение только портретное, iPhone)
enum Screen {
    static var w: CGFloat { UIScreen.main.bounds.width }
    static var h: CGFloat { UIScreen.main.bounds.height }
    static var heroHeight: CGFloat { min(max(h * 0.52, 360), 520) }
}

// MARK: - Аватар с инициалами (пока нет фото тренеров)
struct Avatar: View {
    let initials: String
    var body: some View {
        GeometryReader { g in
            ZStack {
                LinearGradient(colors: [Color(red: 0.14, green: 0.16, blue: 0.08), Color.xCard], startPoint: .topLeading, endPoint: .bottomTrailing)
                Text(initials).font(.system(size: min(g.size.width, g.size.height) * 0.36, weight: .black)).foregroundColor(.xAccent)
            }
        }
    }
}
