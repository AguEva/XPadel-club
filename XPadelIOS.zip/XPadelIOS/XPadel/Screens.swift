import SwiftUI

// MARK: - Главная
struct HomeView: View {
    @EnvironmentObject var router: Router
    private let tileWidth = min(max(Screen.w * 0.42, 140), 190)

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    hero
                    VStack(alignment: .leading, spacing: 14) {
                        SectionTitle(text: "О клубе")
                        Text(Club.about).foregroundColor(Color.xText.opacity(0.9)).lineSpacing(4).fixedSize(horizontal: false, vertical: true)
                        NavigationLink(destination: AboutView()) {
                            Text("Подробнее о клубе").font(.footnote.weight(.semibold)).foregroundColor(.xAccent)
                        }
                    }.padding(.horizontal, 20)

                    VStack(alignment: .leading, spacing: 14) {
                        SectionTitle(text: "Почему выбирают нас")
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 12, alignment: .top)], spacing: 12) {
                            ForEach(Club.features) { f in
                                VStack(alignment: .leading, spacing: 8) {
                                    Image(systemName: f.icon).font(.system(size: 22)).foregroundColor(.xAccent)
                                    Text(f.title).font(.system(size: 16, weight: .bold)).fixedSize(horizontal: false, vertical: true)
                                    Text(f.text).font(.footnote).foregroundColor(.xMuted).fixedSize(horizontal: false, vertical: true)
                                }
                                .frame(maxWidth: .infinity, minHeight: 110, alignment: .topLeading).card()
                            }
                        }
                    }.padding(.horizontal, 20)

                    VStack(alignment: .leading, spacing: 14) {
                        HStack {
                            SectionTitle(text: "Тренеры")
                            Spacer()
                            Button("Все (\(Coaches.all.count))") { router.tab = 3 }.font(.footnote).foregroundColor(.xMuted)
                        }.padding(.horizontal, 20)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(Coaches.all) { c in
                                    NavigationLink(destination: CoachDetail(coach: c)) { CoachTile(coach: c, width: tileWidth) }.buttonStyle(.plain)
                                }
                            }.padding(.horizontal, 20)
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Как нас найти")
                        VStack(alignment: .leading, spacing: 12) {
                            Label(Club.address, systemImage: "mappin.and.ellipse")
                            Label(Club.landmark, systemImage: "location")
                            Label(Club.hours, systemImage: "clock")
                        }
                        .font(.system(size: 15)).foregroundColor(Color.xText.opacity(0.9))
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, alignment: .leading).card()
                        HStack(spacing: 12) {
                            quick("Позвонить", "phone.fill") { openURL(Club.phoneURL) }
                            quick("Маршрут", "map.fill") {
                                let q = Club.address.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                                openURL("http://maps.apple.com/?q=\(q)")
                            }
                        }
                    }.padding(.horizontal, 20)
                    Spacer(minLength: 24)
                }
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationBarHidden(true)
        }.navigationViewStyle(.stack)
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImage(url: Club.heroImage)
                .frame(width: Screen.w, height: Screen.heroHeight).clipped()
            LinearGradient(colors: [Color.black.opacity(0.35), Color.xBg.opacity(0.55), Color.xBg], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 14) {
                Wordmark(size: 24)
                Text("Место, где спорт\nвстречается со стилем")
                    .font(.system(size: 30, weight: .heavy)).lineSpacing(2)
                    .minimumScaleFactor(0.7).lineLimit(3)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(Club.tags, id: \.self) { t in
                            Text(t.uppercased()).font(.system(size: 11, weight: .heavy)).tracking(1)
                                .padding(.horizontal, 10).padding(.vertical, 6)
                                .overlay(Capsule().stroke(Color.xAccent.opacity(0.7), lineWidth: 1))
                                .foregroundColor(.xAccent)
                        }
                    }
                }
                Text("Падел-клуб · \(Club.city) · \(Club.courts) корта").foregroundColor(.xMuted).font(.system(size: 14))
                AccentButton(title: "Записаться", icon: "calendar") { router.tab = 2 }.padding(.top, 2)
            }.padding(20)
        }
        .frame(width: Screen.w, height: Screen.heroHeight).clipped()
    }

    private func quick(_ title: String, _ icon: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 8) { Image(systemName: icon); Text(title).font(.system(size: 15, weight: .semibold)).lineLimit(1).minimumScaleFactor(0.8) }
                .foregroundColor(.white).frame(maxWidth: .infinity, minHeight: 50)
                .background(Color.xCard).cornerRadius(25)
                .overlay(RoundedRectangle(cornerRadius: 25).stroke(Color.xLine, lineWidth: 1))
        }
    }
}

// MARK: - Услуги и цены
struct ServicesView: View {
    @EnvironmentObject var router: Router
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Цены указаны за 1 час. Тарифы зависят от времени: по будням до 15:00 — выгоднее.")
                        .font(.footnote).foregroundColor(.xMuted).fixedSize(horizontal: false, vertical: true)
                    ForEach(Prices.services) { s in ServiceCard(service: s) }
                    VStack(alignment: .leading, spacing: 8) {
                        Label(Prices.balls, systemImage: "tennisball")
                        Label(Prices.racket, systemImage: "tennis.racket")
                    }.font(.footnote).foregroundColor(.xMuted).fixedSize(horizontal: false, vertical: true).padding(.top, 4)
                    AccentButton(title: "Записаться", icon: "calendar") { router.tab = 2 }.padding(.top, 8)
                    Text(Prices.note).font(.caption).foregroundColor(.xMuted).fixedSize(horizontal: false, vertical: true)
                }.padding(20)
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationTitle("Услуги и цены")
        }.navigationViewStyle(.stack)
    }
}

struct ServiceCard: View {
    let service: Service
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                Image(systemName: service.icon).font(.system(size: 20)).foregroundColor(.black)
                    .frame(width: 44, height: 44).background(Color.xAccent).clipShape(Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(service.title).font(.system(size: 17, weight: .bold)).fixedSize(horizontal: false, vertical: true)
                    Text(service.who).font(.footnote).foregroundColor(.xMuted)
                }
                Spacer(minLength: 0)
            }
            Divider().background(Color.xLine)
            ViewThatFits(in: .horizontal) {
                HStack(alignment: .top) {
                    priceBlock(label: "ПН–ПТ до 15:00", price: service.dayPrice, court: service.dayCourt)
                    Spacer(minLength: 12)
                    priceBlock(label: "Основной тариф", price: service.price, court: service.court)
                }
                VStack(alignment: .leading, spacing: 12) {
                    priceBlock(label: "ПН–ПТ до 15:00", price: service.dayPrice, court: service.dayCourt)
                    priceBlock(label: "Основной тариф", price: service.price, court: service.court)
                }
            }
        }.card()
    }

    private func priceBlock(label: String, price: Int?, court: Int?) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.caption).foregroundColor(.xMuted)
            Text(price.map(rub) ?? "—").font(.system(size: 20, weight: .heavy)).lineLimit(1).minimumScaleFactor(0.8)
            if let court { Text("в т.ч. корт \(rub(court))").font(.caption2).foregroundColor(.xMuted) }
        }
    }
}

// MARK: - Запись (YClients внутри приложения)
struct BookingView: View {
    @State private var reloadKey = UUID()
    var body: some View {
        NavigationView {
            Group {
                if let u = URL(string: Club.bookingURL) {
                    WebView(url: u).id(reloadKey).ignoresSafeArea(edges: .bottom)
                } else { Text("Ссылка записи недоступна").foregroundColor(.xMuted) }
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationTitle("Онлайн-запись").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { reloadKey = UUID() } label: { Image(systemName: "arrow.clockwise") }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button { openURL(Club.phoneURL) } label: { Image(systemName: "phone.fill") }
                }
            }
        }.navigationViewStyle(.stack)
    }
}

// MARK: - Тренеры
struct CoachPhoto: View {
    let coach: Coach
    var body: some View {
        if let p = coach.photo { RemoteImage(url: p) } else { Avatar(initials: coach.initials) }
    }
}

struct CoachTile: View {
    let coach: Coach
    var width: CGFloat = 160
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            CoachPhoto(coach: coach).frame(width: width, height: width * 1.18).clipped().cornerRadius(16)
            Text(coach.name).font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                .lineLimit(2).fixedSize(horizontal: false, vertical: true).frame(width: width, alignment: .leading)
            Text(coach.role).font(.caption).foregroundColor(.xMuted).lineLimit(1).frame(width: width, alignment: .leading)
        }
    }
}

struct CoachesView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 14, alignment: .top)], spacing: 22) {
                    ForEach(Coaches.all) { c in
                        NavigationLink(destination: CoachDetail(coach: c)) {
                            CoachGridCard(coach: c)
                        }.buttonStyle(.plain)
                    }
                }.padding(20)
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationTitle("Тренеры")
        }.navigationViewStyle(.stack)
    }
}

struct CoachGridCard: View {
    let coach: Coach
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            CoachPhoto(coach: coach).aspectRatio(0.85, contentMode: .fit).clipped().cornerRadius(16)
            Text(coach.name).font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 6) {
                Text(coach.role).font(.caption).foregroundColor(.xMuted).lineLimit(1)
                if coach.siteVideo || coach.videoURL != nil {
                    Image(systemName: "play.circle.fill").font(.caption).foregroundColor(.xAccent)
                }
            }
        }
    }
}

struct CoachDetail: View {
    let coach: Coach
    @EnvironmentObject var router: Router
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                CoachPhoto(coach: coach).frame(height: min(Screen.w * 0.9, 360)).frame(maxWidth: .infinity).clipped().cornerRadius(20)
                Text(coach.name).font(.system(size: 26, weight: .heavy)).fixedSize(horizontal: false, vertical: true)
                Text(coach.role.uppercased()).font(.system(size: 12, weight: .heavy)).tracking(1.4).foregroundColor(.xAccent)
                Text(coach.bio).foregroundColor(Color.xText.opacity(0.9)).lineSpacing(4).fixedSize(horizontal: false, vertical: true)
                if !coach.facts.isEmpty {
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(coach.facts, id: \.self) { f in
                            HStack(alignment: .top, spacing: 10) {
                                Image(systemName: "checkmark.circle.fill").foregroundColor(.xAccent)
                                Text(f).fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading).card()
                }
                if let v = coach.videoURL {
                    NavigationLink(destination: WebScreen(title: "Видеообзор", url: v)) {
                        videoRow("Смотреть видеообзор")
                    }.buttonStyle(.plain)
                } else if coach.siteVideo {
                    NavigationLink(destination: WebScreen(title: coach.name, url: Club.site + coach.page)) {
                        videoRow("Видео-представление тренера")
                    }.buttonStyle(.plain)
                }
                AccentButton(title: "Записаться на тренировку", icon: "calendar") { router.tab = 2 }
                NavigationLink(destination: WebScreen(title: coach.name, url: Club.site + coach.page)) {
                    Text("Страница тренера на сайте").foregroundColor(.xMuted).font(.footnote).frame(maxWidth: .infinity)
                }
            }.padding(20)
        }
        .background(Color.xBg.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
    }

    private func videoRow(_ title: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "play.fill").foregroundColor(.black).frame(width: 40, height: 40).background(Color.xAccent).clipShape(Circle())
            Text(title).font(.system(size: 16, weight: .semibold)).foregroundColor(.white)
            Spacer()
            Image(systemName: "chevron.right").foregroundColor(.xMuted)
        }.card()
    }
}

// MARK: - О клубе
struct AboutView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Wordmark(size: 28)
                Text(Club.slogan).font(.system(size: 22, weight: .heavy)).fixedSize(horizontal: false, vertical: true)
                Text(Club.about).lineSpacing(4).fixedSize(horizontal: false, vertical: true)
                Text(Club.about2).lineSpacing(4).foregroundColor(.xMuted).fixedSize(horizontal: false, vertical: true)
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 12, alignment: .top)], spacing: 12) {
                    ForEach(Club.features) { f in
                        HStack(spacing: 10) {
                            Image(systemName: f.icon).foregroundColor(.xAccent)
                            Text(f.title).font(.system(size: 14, weight: .semibold)).fixedSize(horizontal: false, vertical: true)
                            Spacer(minLength: 0)
                        }.card()
                    }
                }
            }.padding(20)
        }
        .background(Color.xBg.ignoresSafeArea())
        .navigationTitle("О клубе").navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Клуб: контакты, о нас, документы
struct MoreView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Контакты")
                        VStack(spacing: 0) {
                            row("phone.fill", "Телефон (запись)", Club.phoneDisplay) { openURL(Club.phoneURL) }
                            row("envelope.fill", "Email", Club.email) { openURL("mailto:\(Club.email)") }
                            row("mappin.and.ellipse", "Адрес", Club.address) {
                                let q = Club.address.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                                openURL("http://maps.apple.com/?q=\(q)")
                            }
                            row("clock.fill", "Режим работы", Club.hours, last: true) {}
                        }.background(Color.xCard).cornerRadius(18)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Мы в соцсетях")
                        VStack(spacing: 0) {
                            ForEach(Array(Club.socials.enumerated()), id: \.element.id) { i, s in
                                row(s.icon, s.title, "Открыть", last: i == Club.socials.count - 1) { openURL(s.url) }
                            }
                        }.background(Color.xCard).cornerRadius(18)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "О клубе")
                        Text(Club.about).foregroundColor(Color.xText.opacity(0.9)).lineSpacing(4).fixedSize(horizontal: false, vertical: true)
                        NavigationLink(destination: AboutView()) {
                            Text("Подробнее").font(.footnote.weight(.semibold)).foregroundColor(.xAccent)
                        }
                        NavigationLink(destination: WebScreen(title: "Сайт клуба", url: Club.site)) {
                            Text("Открыть сайт xpadel33.ru").font(.footnote).foregroundColor(.xMuted)
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Документы")
                        VStack(spacing: 0) {
                            ForEach(Array(Club.docs.enumerated()), id: \.element.id) { i, d in
                                NavigationLink(destination: WebScreen(title: d.title, url: Club.site + d.path)) {
                                    HStack {
                                        Text(d.title).foregroundColor(.white).multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
                                        Spacer()
                                        Image(systemName: "chevron.right").foregroundColor(.xMuted)
                                    }.padding(16)
                                }
                                if i < Club.docs.count - 1 { Divider().background(Color.xLine).padding(.leading, 16) }
                            }
                        }.background(Color.xCard).cornerRadius(18)
                        Text(Club.legal).font(.caption).foregroundColor(.xMuted)
                    }
                    Wordmark(size: 18).frame(maxWidth: .infinity)
                }.padding(20)
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationTitle("Клуб")
        }.navigationViewStyle(.stack)
    }

    private func row(_ icon: String, _ title: String, _ value: String, last: Bool = false, action: @escaping () -> Void) -> some View {
        VStack(spacing: 0) {
            Button(action: action) {
                HStack(spacing: 14) {
                    Image(systemName: icon).foregroundColor(.xAccent).frame(width: 24)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title).font(.caption).foregroundColor(.xMuted)
                        Text(value).foregroundColor(.white).multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
                    }
                    Spacer(minLength: 0)
                }.padding(16)
            }
            if !last { Divider().background(Color.xLine).padding(.leading, 54) }
        }
    }
}
