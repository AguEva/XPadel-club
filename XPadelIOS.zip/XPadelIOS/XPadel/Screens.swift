import SwiftUI

// MARK: - Главная
struct HomeView: View {
    @EnvironmentObject var router: Router

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 28) {
                    hero
                    VStack(alignment: .leading, spacing: 14) {
                        SectionTitle(text: "О клубе")
                        Text(Club.about).foregroundColor(Color.xText.opacity(0.9)).lineSpacing(4)
                    }.padding(.horizontal, 20)

                    VStack(alignment: .leading, spacing: 14) {
                        SectionTitle(text: "Почему XPadel")
                        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                            ForEach(Club.features) { f in
                                VStack(alignment: .leading, spacing: 8) {
                                    Image(systemName: f.icon).font(.system(size: 22)).foregroundColor(.xAccent)
                                    Text(f.title).font(.system(size: 16, weight: .bold))
                                    Text(f.text).font(.footnote).foregroundColor(.xMuted)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading).card()
                            }
                        }
                    }.padding(.horizontal, 20)

                    VStack(alignment: .leading, spacing: 14) {
                        HStack {
                            SectionTitle(text: "Тренеры")
                            Spacer()
                            Button("Все") { router.tab = 3 }.font(.footnote).foregroundColor(.xMuted)
                        }
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(Coaches.all) { c in
                                    NavigationLink(destination: CoachDetail(coach: c)) { CoachTile(coach: c) }.buttonStyle(.plain)
                                }
                            }
                        }
                    }.padding(.horizontal, 20)

                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Как нас найти")
                        VStack(alignment: .leading, spacing: 10) {
                            Label(Club.address, systemImage: "mappin.and.ellipse")
                            Label(Club.landmark, systemImage: "location")
                            Label(Club.hours, systemImage: "clock")
                        }.font(.system(size: 15)).foregroundColor(Color.xText.opacity(0.9)).frame(maxWidth: .infinity, alignment: .leading).card()
                        HStack(spacing: 12) {
                            quick("Позвонить", "phone.fill") { openURL(Club.phoneURL) }
                            quick("Маршрут", "map.fill") {
                                let q = (Club.address).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                                openURL("http://maps.apple.com/?q=\(q)")
                            }
                        }
                    }.padding(.horizontal, 20)
                    Spacer(minLength: 24)
                }
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationBarHidden(true)
        }.navigationViewStyle(.stack)
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImage(url: Club.heroImage).frame(height: 460).clipped()
            LinearGradient(colors: [.clear, Color.xBg.opacity(0.65), Color.xBg], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 14) {
                Wordmark(size: 26)
                Text("Место, где спорт\nвстречается со стилем").font(.system(size: 30, weight: .heavy)).lineSpacing(2)
                Text("Падел-клуб · \(Club.city) · \(Club.courts) корта").foregroundColor(.xMuted).font(.system(size: 14))
                AccentButton(title: "Записаться", icon: "calendar") { router.tab = 2 }.padding(.top, 4)
            }.padding(20)
        }
        .frame(height: 460).clipped()
    }

    private func quick(_ title: String, _ icon: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 8) { Image(systemName: icon); Text(title).font(.system(size: 15, weight: .semibold)) }
                .foregroundColor(.white).frame(maxWidth: .infinity, minHeight: 50)
                .background(Color.xCard).cornerRadius(25)
                .overlay(RoundedRectangle(cornerRadius: 25).stroke(Color.xLine, lineWidth: 1))
        }
    }
}

// MARK: - Услуги и цены
struct ServicesView: View {
    @EnvironmentObject var router: Router
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Цены указаны за 1 час. Тарифы зависят от времени: по будням до 15:00 — выгоднее.")
                        .font(.footnote).foregroundColor(.xMuted)
                    ForEach(Prices.services) { s in ServiceCard(service: s) }
                    VStack(alignment: .leading, spacing: 8) {
                        Label(Prices.balls, systemImage: "tennisball")
                        Label(Prices.racket, systemImage: "tennis.racket")
                    }.font(.footnote).foregroundColor(.xMuted).padding(.top, 4)
                    AccentButton(title: "Записаться", icon: "calendar") { router.tab = 2 }.padding(.top, 8)
                    Text(Prices.note).font(.caption).foregroundColor(.xMuted)
                }.padding(20)
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationTitle("Услуги и цены")
        }.navigationViewStyle(.stack)
    }
}

struct ServiceCard: View {
    let service: Service
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                Image(systemName: service.icon).font(.system(size: 20)).foregroundColor(.black)
                    .frame(width: 44, height: 44).background(Color.xAccent).clipShape(Circle())
                VStack(alignment: .leading, spacing: 2) {
                    Text(service.title).font(.system(size: 17, weight: .bold))
                    Text(service.who).font(.footnote).foregroundColor(.xMuted)
                }
                Spacer()
            }
            Divider().background(Color.xLine)
            HStack(alignment: .top) {
                priceBlock(label: "ПН–ПТ до 15:00", price: service.dayPrice, court: service.dayCourt)
                Spacer()
                priceBlock(label: "Основной тариф", price: service.price, court: service.court)
            }
        }.card()
    }

    private func priceBlock(label: String, price: Int?, court: Int?) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label).font(.caption).foregroundColor(.xMuted)
            Text(price.map(rub) ?? "—").font(.system(size: 20, weight: .heavy))
            if let court { Text("в т.ч. корт \(rub(court))").font(.caption2).foregroundColor(.xMuted) }
        }
    }
}

// MARK: - Запись (YClients внутри приложения)
struct BookingView: View {
    @State private var reloadKey = UUID()
    var body: some View {
        NavigationView {
            Group {
                if let u = URL(string: Club.bookingURL) {
                    WebView(url: u).id(reloadKey).ignoresSafeArea(edges: .bottom)
                } else { Text("Ссылка записи недоступна").foregroundColor(.xMuted) }
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationTitle("Онлайн-запись").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { reloadKey = UUID() } label: { Image(systemName: "arrow.clockwise") }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    Button { openURL(Club.phoneURL) } label: { Image(systemName: "phone.fill") }
                }
            }
        }.navigationViewStyle(.stack)
    }
}

// MARK: - Тренеры
struct CoachTile: View {
    let coach: Coach
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            ZStack {
                Color.xCard
                if coach.photo != nil { RemoteImage(url: coach.photo) }
                else { Image(systemName: "person.fill").font(.system(size: 40)).foregroundColor(.xMuted) }
            }
            .frame(width: 160, height: 190).clipped().cornerRadius(16)
            Text(coach.name).font(.system(size: 15, weight: .bold)).foregroundColor(.white).lineLimit(2).frame(width: 160, alignment: .leading)
            Text(coach.role).font(.caption).foregroundColor(.xMuted)
        }
    }
}

struct CoachesView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 14) {
                    ForEach(Coaches.all) { c in
                        NavigationLink(destination: CoachDetail(coach: c)) {
                            HStack(spacing: 14) {
                                ZStack {
                                    Color.xBg
                                    if c.photo != nil { RemoteImage(url: c.photo) }
                                    else { Image(systemName: "person.fill").foregroundColor(.xMuted) }
                                }.frame(width: 76, height: 76).clipped().clipShape(Circle())
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(c.name).font(.system(size: 17, weight: .bold)).foregroundColor(.white)
                                    Text(c.role).font(.footnote).foregroundColor(.xMuted)
                                }
                                Spacer()
                                Image(systemName: "chevron.right").foregroundColor(.xMuted)
                            }.card()
                        }.buttonStyle(.plain)
                    }
                }.padding(20)
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationTitle("Тренеры")
        }.navigationViewStyle(.stack)
    }
}

struct CoachDetail: View {
    let coach: Coach
    @EnvironmentObject var router: Router
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                ZStack {
                    Color.xCard
                    if coach.photo != nil { RemoteImage(url: coach.photo) }
                    else { Image(systemName: "person.fill").font(.system(size: 64)).foregroundColor(.xMuted) }
                }.frame(height: 340).clipped().cornerRadius(20)
                Text(coach.name).font(.system(size: 26, weight: .heavy))
                Text(coach.role.uppercased()).font(.system(size: 12, weight: .heavy)).tracking(1.4).foregroundColor(.xAccent)
                Text(coach.bio).foregroundColor(Color.xText.opacity(0.9)).lineSpacing(4)
                if !coach.facts.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(coach.facts, id: \.self) { f in
                            HStack(alignment: .top, spacing: 10) {
                                Image(systemName: "checkmark.circle.fill").foregroundColor(.xAccent)
                                Text(f)
                            }
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading).card()
                }
                NavigationLink(destination: WebScreen(title: coach.name, url: Club.site + coach.page)) {
                    Text("Страница тренера на сайте").foregroundColor(.xMuted).font(.footnote)
                }
                AccentButton(title: "Записаться на тренировку", icon: "calendar") { router.tab = 2 }
            }.padding(20)
        }
        .background(Color.xBg.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Клуб: контакты, о нас, документы
struct MoreView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Контакты")
                        VStack(spacing: 0) {
                            row("phone.fill", "Телефон", Club.phoneDisplay) { openURL(Club.phoneURL) }
                            row("envelope.fill", "Email", Club.email) { openURL("mailto:\(Club.email)") }
                            row("mappin.and.ellipse", "Адрес", Club.address) {
                                let q = Club.address.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                                openURL("http://maps.apple.com/?q=\(q)")
                            }
                            row("clock.fill", "Режим работы", Club.hours, last: true) {}
                        }.background(Color.xCard).cornerRadius(18)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Мы в соцсетях")
                        VStack(spacing: 0) {
                            ForEach(Array(Club.socials.enumerated()), id: \.element.id) { i, s in
                                row(s.icon, s.title, "Открыть", last: i == Club.socials.count - 1) { openURL(s.url) }
                            }
                        }.background(Color.xCard).cornerRadius(18)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "О клубе")
                        Text(Club.about).foregroundColor(Color.xText.opacity(0.9)).lineSpacing(4)
                        NavigationLink(destination: WebScreen(title: "О клубе", url: Club.site + "/about")) {
                            Text("Подробнее на сайте").font(.footnote).foregroundColor(.xAccent)
                        }
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        SectionTitle(text: "Документы")
                        VStack(spacing: 0) {
                            ForEach(Array(Club.docs.enumerated()), id: \.element.id) { i, d in
                                NavigationLink(destination: WebScreen(title: d.title, url: Club.site + d.path)) {
                                    HStack {
                                        Text(d.title).foregroundColor(.white).multilineTextAlignment(.leading)
                                        Spacer()
                                        Image(systemName: "chevron.right").foregroundColor(.xMuted)
                                    }.padding(16)
                                }
                                if i < Club.docs.count - 1 { Divider().background(Color.xLine).padding(.leading, 16) }
                            }
                        }.background(Color.xCard).cornerRadius(18)
                        Text(Club.legal).font(.caption).foregroundColor(.xMuted)
                    }
                    Wordmark(size: 18).frame(maxWidth: .infinity)
                }.padding(20)
            }
            .background(Color.xBg.ignoresSafeArea())
            .navigationTitle("Клуб")
        }.navigationViewStyle(.stack)
    }

    private func row(_ icon: String, _ title: String, _ value: String, last: Bool = false, action: @escaping () -> Void) -> some View {
        VStack(spacing: 0) {
            Button(action: action) {
                HStack(spacing: 14) {
                    Image(systemName: icon).foregroundColor(.xAccent).frame(width: 24)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title).font(.caption).foregroundColor(.xMuted)
                        Text(value).foregroundColor(.white).multilineTextAlignment(.leading)
                    }
                    Spacer()
                }.padding(16)
            }
            if !last { Divider().background(Color.xLine).padding(.leading, 54) }
        }
    }
}
